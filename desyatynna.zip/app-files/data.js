var APP_DATA = {
  "scenes": [
    {
      "id": "0--",
      "name": "Початок огляду",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": -0.18162515773922117,
        "pitch": 0.018102366309801,
        "fov": 0.9182749834975337
      },
      "linkHotspots": [
        {
          "yaw": 0.004563765568837752,
          "pitch": 0.25525691181341337,
          "rotation": 0,
          "target": "1--"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1--",
      "name": "Продовження огляду",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 0.0522636481371439,
        "pitch": -0.008766359398338253,
        "fov": 1.3635993899637084
      },
      "linkHotspots": [
        {
          "yaw": 0.42502591098422116,
          "pitch": 0.2912565346394942,
          "rotation": 0,
          "target": "2--1"
        },
        {
          "yaw": -3.098071785343606,
          "pitch": 0.3140572411913052,
          "rotation": 0,
          "target": "0--"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2--1",
      "name": "Зал 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 1.8139765143159252,
        "pitch": 0.031029517594388878,
        "fov": 1.3635993899637084
      },
      "linkHotspots": [
        {
          "yaw": 2.7069187619568007,
          "pitch": 0.3122543248698779,
          "rotation": 0,
          "target": "3--2"
        },
        {
          "yaw": 1.9089799959403582,
          "pitch": 0.3075980311776121,
          "rotation": 0,
          "target": "4--3-1"
        },
        {
          "yaw": -2.3045603919182547,
          "pitch": 0.45475719527566305,
          "rotation": 0,
          "target": "1--"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3--2",
      "name": "Зал 2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 0.2797334941484486,
        "pitch": -0.0021938027815089356,
        "fov": 1.3635993899637084
      },
      "linkHotspots": [
        {
          "yaw": 1.465872741543877,
          "pitch": 0.4587615231879454,
          "rotation": 0,
          "target": "2--1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4--3-1",
      "name": "Зал 3-1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 0.6625664173249035,
        "pitch": -0.010340743444826828,
        "fov": 1.3635993899637084
      },
      "linkHotspots": [
        {
          "yaw": 1.4987108270601226,
          "pitch": 0.3995019796339143,
          "rotation": 0,
          "target": "2--1"
        },
        {
          "yaw": -3.0741511759565334,
          "pitch": 0.25724913149886675,
          "rotation": 0,
          "target": "5--3-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "5--3-2",
      "name": "Зал 3-2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 0,
        "pitch": 0,
        "fov": 1.3635993899637084
      },
      "linkHotspots": [
        {
          "yaw": 0.016416067673041823,
          "pitch": 0.23367401762532047,
          "rotation": 0,
          "target": "4--3-1"
        },
        {
          "yaw": 0.5134385326797783,
          "pitch": 0.22805084311086077,
          "rotation": 0,
          "target": "2--1"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Desyatynna",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
